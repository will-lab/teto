use teto
go

drop table price
drop table supplier
drop table product


go