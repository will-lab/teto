create database teto
go